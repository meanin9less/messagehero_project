
export default function Mystyle(){
    return(
        <>
            <div>
                <h3>내스타일 만들기</h3>
                <input type="text"></input>
                <br></br>
                <textarea></textarea>
                <br></br>
                <button>추가</button>
            </div>
            <div>
                <h3>내스타일</h3>
                <ul>
                    <p>서식 목록이 들어갈 자리</p>
                </ul>
            </div>
        </>
    )
}