
export default function Blacklist(){
    return(
        <>
            <div>
            <h3>유해번호조회</h3>
            </div>
            <div>
                <input type="text"></input>
                <button>검색</button>
            </div>
            <div>
                <p>번호검색결과 자리</p>
            </div>
        </>
    )
}